let itemList =  document.querySelector('.items');
let cart = document.querySelector('.cart');
let cartList = document.querySelector('.cart-list');
let total = document.querySelector('.total');
let tax = document.querySelector('.tax');
let subtotal = document.querySelector('.subtotal');


let items = [
    {
        id: 1,
        name: 'Axumawit Tigray Dress',
        image: 'https://i.etsystatic.com/43727774/r/il/34bf5e/5026774207/il_794xN.5026774207_9eby.jpg',
        price: 500
    },
    {
        id: 2,
        name: 'Axum Dress Tigray',
        image: 'https://i.etsystatic.com/23382866/r/il/9147fd/4574402022/il_794xN.4574402022_8hnx.jpg',
        price: 450
    },
    {
        id: 3,
        name: 'Shifon Tigray',
        image: 'https://i.etsystatic.com/43727774/r/il/a262b8/5576951592/il_794xN.5576951592_9p22.jpg',
        price: 300
    },
    {
        id: 4,
        name: 'Tigray Cultural Dress ',
        image: 'https://i.etsystatic.com/43727774/r/il/ea1ded/4938157216/il_794xN.4938157216_azf7.jpg',
        price: 350
    },
    {
        id: 5,
        name: 'Shifon Tigray',
        image: 'https://i.etsystatic.com/23382866/r/il/8e6483/5656632562/il_794xN.5656632562_rjzo.jpg',
        price: 250
    },
    {
        id: 6,
        name: 'Tigray Cultral Hair Dressing',
        image: 'https://i.etsystatic.com/36547327/r/il/a91cf7/4691636166/il_794xN.4691636166_4rob.jpg',
         price: 1000
    }
]

function initItem() {
    items.forEach((value, key) => {
        let card = document.createElement('div');
        card.classList.add('card');
        card.setAttribute('style', 'width: 15rem;');
        card.innerHTML = `
            <img src="${value.image}"style="width:200px;height:250px;" class="card-img-top" alt="...">
            <div class="card-body">
                <h4 class="card-title text-center">${value.name}</h4>
                <p class="card-text text-center">Price: ${value.price}</p>
                <button class="add-to-cart btn btn-dark form-control" onclick="addToCart(${key})">Add to Cart</button>
            </div>`;
        itemList.appendChild(card);
    });
}

initItem();

let cartLists = [];

function addToCart(key) {
    if (cartLists[key] == null) {
        cartLists[key] = JSON.parse(JSON.stringify(items[key]));
        cartLists[key].quantity = 1;
    }
    reloadCart();
}

function reloadCart() {
    cartList.innerHTML = '';
    let totalPrice = 0;
    cartLists.forEach((value, key) => {
        totalPrice = totalPrice + value.price;

        if (value != null) {
            let listItem = document.createElement('li');
            listItem.setAttribute('class', 'list-group-item');
            listItem.innerHTML = `
                <div><img src="${value.image}" style="width: 60px"/></div>
                <div><h5 class="mt-1">${value.name}</h5></div>
                <div><h6 class="mt-2">${value.price.toLocaleString()}</h6></div>
                <div>
                    <button onclick="changeQuantity(${key}, ${value.quantity - 1})">-</button>
                    <div class="count m-2">${value.quantity}</div>
                    <button onclick="changeQuantity(${key}, ${value.quantity + 1})">+</button>
                </div>`;
            cartList.appendChild(listItem);
        }
    });

    // Calculate subtotal, tax, and total
    subtotal.innerText = totalPrice.toLocaleString();
    tax.innerText = (totalPrice * 0.15).toLocaleString(); // Assuming 15% tax
    total.innerText = (totalPrice + parseFloat(tax.innerText)).toLocaleString();

    quantity.innerText = count;
}

function changeQuantity(key, quantity) {
    if (quantity == 0) {
        delete cartLists[key];
    } else {
        cartLists[key].quantity = quantity;
        cartLists[key].price = quantity * items[key].price;
    }
    reloadCart();
}

function clearCart() {
    cartLists = [];
    reloadCart();
}